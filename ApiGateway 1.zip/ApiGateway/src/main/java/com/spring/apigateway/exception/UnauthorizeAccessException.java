package com.spring.apigateway.exception;

public class UnauthorizeAccessException extends Exception{
	public UnauthorizeAccessException(String msg) {
		super(msg);
	}
	public UnauthorizeAccessException() {
		super("Unathorized");
	}

}
