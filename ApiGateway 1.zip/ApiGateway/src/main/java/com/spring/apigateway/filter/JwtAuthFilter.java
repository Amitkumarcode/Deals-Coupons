package com.spring.apigateway.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;

import com.spring.apigateway.exception.UnauthorizeAccessException;
import com.spring.apigateway.utility.JwtUtility;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JwtAuthFilter extends AbstractGatewayFilterFactory<JwtAuthFilter.Config>{
	
	@Autowired
	private RouteValidator routeValidator;
	
	@Autowired
	private JwtUtility jwtUtility;
	
	public JwtAuthFilter() {
		super(Config.class);
	}
	
	@Override
	public GatewayFilter apply(Config config){
		return ((exchange,chain) -> {
			
			if(routeValidator.isSecured.test(exchange.getRequest())) {
				if(!exchange.getRequest().getHeaders().containsKey("Authorization")) {
					throw new RuntimeException("Missing Authorization Header");
				}
				String header = exchange.getRequest().getHeaders().get("Authorization").get(0);
				String token = null;
				if(header != null && header.startsWith("Bearer ")) {
					token = header.substring(7);
				}
				try {
					log.info("token {}",token);
					jwtUtility.validateToken(token);
					log.info("valid token {}",token);
					String role = jwtUtility.extractRole(token);
					String path = exchange.getRequest().getURI().getPath();
					if(!checkRole(role,path)) {
						throw new UnauthorizeAccessException("Unauthorized Access!");
					}
				}
				catch(Exception e) {
					e.printStackTrace();
					System.out.println("Invalid access...!");
                    throw new RuntimeException("You do not have access ! ");
				}	
			}
			return chain.filter(exchange);
		});
	}
	

	private boolean checkRole(String role, String path) {
		// TODO Auto-generated method stub
		if(role.equals("Admin")) {
			//return true;
			return(path.startsWith("/cart/findAll")||path.startsWith("/cart/find/cartId/{cartId}")||path.startsWith("/cart/find/userId/{userId}")||path.startsWith("/coupons")||path.startsWith("/deals")||path.startsWith("/auth/alluser"));
		}else if(role.equals("User")) {
			return(path.startsWith("/cart/add/{userId}/{id}")||path.startsWith("/cart/deleteItem/{userId}/{id}")||path.startsWith("/coupons/allCoupons")||path.startsWith("/coupons/get/category/{category}")||path.startsWith("/deals/allDeals")||path.startsWith("/deals/get/category/{category}"));
		}
		System.out.println("hello");
		return false;
	}


	public static class Config{
		
	} 
}
