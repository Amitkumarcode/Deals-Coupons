package com.spring.apigateway.utility;

import java.security.Key;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JwtUtility {
	
	private String jwtSecret = "5367566B59703373367639792F423F4528482B4D6251655468576D5A71347437";

//	public void validateToken(String token) {
//			Jwts.parserBuilder().setSigningKey(jwtSecret).build().parseClaimsJws(token);	
//		
//	}
	public void validateToken(final String token) {
    	log.info("Token {}",token);
        Jwts.parserBuilder().setSigningKey(getSignKey()).build().parseClaimsJws(token);
    }
	private Key getSignKey() {
        byte[] keyBytes = Decoders.BASE64.decode(jwtSecret);
        return Keys.hmacShaKeyFor(keyBytes);
    }
	public String extractRole(String token) {
		
		Claims claims = Jwts.parserBuilder()
                .setSigningKey(jwtSecret)
                .build()
                .parseClaimsJws(token)
                .getBody();
		log.info("claims: {}", claims);
        return (String) claims.get("ROLE");
	}

}
