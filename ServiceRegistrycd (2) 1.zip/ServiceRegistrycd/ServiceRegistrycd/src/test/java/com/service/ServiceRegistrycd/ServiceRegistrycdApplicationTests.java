package com.service.ServiceRegistrycd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistrycdApplicationTests {

	@Test
	void contextLoads() {
	}

}
