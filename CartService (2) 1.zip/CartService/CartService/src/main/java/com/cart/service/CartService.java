package com.cart.service;

import java.util.List;
import java.util.Optional;

import com.cart.model.Cart;
//import com.cart.model.TransactionDetails;

public interface CartService {
	
	Cart save(String userId, String id);

	List<Cart> findAll();



	double getTotalPrice(Cart cart);



	Cart findByCartId(String cartId);

	Optional<Cart> findByUserId(String userId);
	
	String deleteCartProductsByUserId(String userId, String id);

	String deleteCartByUserId(String userId);

	void deleteAll();

	

	

//	TransactionDetails createTransaction(Integer amount);
}
