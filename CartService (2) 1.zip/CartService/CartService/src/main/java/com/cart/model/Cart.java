package com.cart.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Document("user_cart")
public class Cart {
	
	@Id
	private String cartId;
	@Field
	private String userId;
	
	List<Coupons> coupons = new ArrayList<>();
	
	List<Deals> deals = new ArrayList<>();
	
	double totalAmount=0;
}
