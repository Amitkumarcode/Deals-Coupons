package com.cart.service.external.services;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cart.model.Coupons;
import com.cart.model.Deals;

@FeignClient(name = "DEALSANDCOUPONS")
public interface DealsAndCouponsService {
	
	@GetMapping("/deals/get/{id}")
	public Deals getDealsById(@PathVariable("id") String productId);
	
	@GetMapping("/coupons/get/{id}")
	public Coupons getCouponById(@PathVariable("id") String couponId);
}
