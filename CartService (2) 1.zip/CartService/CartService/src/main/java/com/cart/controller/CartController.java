package com.cart.controller;



import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cart.model.Cart;
//import com.cart.model.TransactionDetails;
import com.cart.service.CartService;

@RestController
@RequestMapping("/cart")
@CrossOrigin("*")
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	
	
	@PostMapping("/add/{userId}/{id}")
	public ResponseEntity<Cart> addCart(@PathVariable("userId") String userId, @PathVariable("id") String id){
		Cart cart1 = cartService.save(userId, id);
		return new ResponseEntity<>(cart1, HttpStatus.CREATED);
	}
	
	@GetMapping("/findAll")
	public ResponseEntity<List<Cart>> findAll(){
		List<Cart> listOfAllCartItems = cartService.findAll();
		return new ResponseEntity<>(listOfAllCartItems, HttpStatus.ACCEPTED);
	}
	

	@GetMapping("/find/cartId/{cartId}")
	public ResponseEntity<Cart> findByCartId(@PathVariable("cartId") String cartId){
		Cart cart = cartService.findByCartId(cartId);
		return new ResponseEntity<>(cart, HttpStatus.OK);
	}
	
	@GetMapping("/find/userId/{userId}")
	public ResponseEntity<Optional<Cart>> findByUserId(@PathVariable("userId") String userId){
		Optional<Cart> cartListByUserId = cartService.findByUserId(userId);
		return new ResponseEntity<>(cartListByUserId, HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteItem/{userId}/{id}")
	public ResponseEntity<Object> deleteCartById(@PathVariable("userId") String userId, @PathVariable("id") String id){
		String result = cartService.deleteCartProductsByUserId(userId, id);
		Map<String, String> response =new HashMap<String, String>();
		response.put("result", result);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	@DeleteMapping("/deleteCart/{userId}")
	public String deleteCartByUserId(@PathVariable String userId) {
		return cartService.deleteCartByUserId(userId);
	}
	@DeleteMapping("/deleteAll")
	public String deleteAll() {
		cartService.deleteAll();
		return "All Cart Deleted";
	}
	
//	@GetMapping("/createTransaction/{amount}")
//	public TransactionDetails createTransaction(@PathVariable("amount")Integer amount) {
//		return cartService.createTransaction(amount);
//	}
}
