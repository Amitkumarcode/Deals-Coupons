package com.cart.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Deals {
	
	private String productId;
	private String productName;
	private double price=0;
	private String rating;
	private int quantity=1;
	private String category;
	private double discountPercentage=0;
	private double discountedPrice=0;
	private String description;
	private String image;
	
}
