package com.cart.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cart.payload.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(ItemNotFoundInCartException.class)
	public ResponseEntity<ApiResponse> handleItemNotFoundException(ItemNotFoundInCartException ex){
		
		String message = ex.getMessage();
		ApiResponse build = ApiResponse.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
		System.out.println("Inside Exception");
		return new ResponseEntity<>(build, HttpStatus.NOT_FOUND);
	}
	
}