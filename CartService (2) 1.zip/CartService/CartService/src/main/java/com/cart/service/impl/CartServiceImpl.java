package com.cart.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cart.exceptions.ItemNotFoundInCartException;
import com.cart.model.Cart;
import com.cart.model.Coupons;
import com.cart.model.Deals;
//import com.cart.model.TransactionDetails;
//import com.cart.model.UserCredential;
import com.cart.repository.CartRepository;
import com.cart.service.CartService;
import com.cart.service.external.services.DealsAndCouponsService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
//import com.cart.service.external.services.UserService;

@Service
public class CartServiceImpl implements CartService {
//private static final String KEY="rzp_test_AXBzvN2fkD4ESK";
//private static final String KEY_SECRET="bsZmiVD7p1GMo6haWiy4SHSH";
//private static final String CURRENCY="INR";
	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private DealsAndCouponsService dealsAndCouponsService;

	
	Logger lg = LoggerFactory.getLogger(CartServiceImpl.class);
	@Override
	public Cart save(String userId, String id) {

		Cart cart = new Cart();
		lg.info("Creating new cart,incase cart for a given user is not present");

		Coupons coupon = dealsAndCouponsService.getCouponById(id);
		Optional<Cart> oldcart = findByUserId(userId);


		if (coupon != null) {
			lg.info("Checking if the Coupons is not null");
			try {
				lg.info("Checking If Cart already exists");
				if (oldcart != null)
				{lg.info("Traversing through old cart for an user and checking if the coupons is already existing,If exixting returning the old cart");
					for(Coupons c: oldcart.get().getCoupons()){
						
						if(c.getCouponId().equals(id)) {
							
							return oldcart.get();
						}
					}lg.info("If coupons doesnot exist in the cart then adding it to the cart");
					oldcart.get().getCoupons().add(coupon);
					return cartRepository.save(oldcart.get());
				} else {
					lg.info("If the cart was not existing for a new customer then making a new cart and setting the userId and Coupons bought");
					cart.setUserId(userId);
					cart.setCoupons(Arrays.asList(coupon));
					return cartRepository.save(cart);
				}

			} catch (Exception e) {
				// TODO: handle exception
			}
		} else {lg.info("Checking if the id is for deals");
			Deals deal = dealsAndCouponsService.getDealsById(id);
lg.info("if the cart already exists and if the deal already existing then increasing the quantity");
			if (oldcart != null) {
				for (Deals d : oldcart.get().getDeals()) {
					if (d.getProductId().equals(id)) {
						d.setQuantity(d.getQuantity() + 1);
						return cartRepository.save(oldcart.get());
					}
				}  lg.info("If the deal is not already present in the cart then adding the deal");
				oldcart.get().getDeals().add(deal);
				return cartRepository.save(oldcart.get());
			} else {lg.info("if the cart doesnot exist for a new user then adding the cart and setting the cart");
				cart.setUserId(userId);
				cart.setDeals(Arrays.asList(deal));
				return cartRepository.save(cart);
			}
		}
		return cartRepository.save(cart);
	}

	@Override
	public List<Cart> findAll() {
		lg.info("Returning all the carts");
		List<Cart> listOfAddedItems = cartRepository.findAll();
		return listOfAddedItems;
	}



	@Override
	public Cart findByCartId(String cartId) {
		Optional<Cart> optionalCart = cartRepository.findById(cartId);
		if (optionalCart.isEmpty()) {
			throw new ItemNotFoundInCartException("Id is not found");
		} else {
			return optionalCart.get();
		}
	}

	@Override
	public Optional<Cart> findByUserId(String userId) {
		Optional<Cart> optionalCart = cartRepository.findByUserId(userId);
		if (optionalCart.isEmpty()) {

			return null;
		} else {
			optionalCart.get().setTotalAmount(getTotalPrice(optionalCart.get()));
			return optionalCart;
		}
	}

	@Override
	public double getTotalPrice(Cart cart) {

		List<Coupons> coupon = cart.getCoupons();

		double sumOfCoupons = 0;
		for (Coupons c : coupon) {
			sumOfCoupons += c.getPrice();
		}

		List<Deals> deals = cart.getDeals();
		
		double sumOfDeals = 0;
		for (Deals d : deals) {
			sumOfDeals += (d.getDiscountedPrice()*d.getQuantity());
		}

		return sumOfCoupons + sumOfDeals;
	}
	

	@Override
	public String deleteCartProductsByUserId(String userId, String id) {
		
		Optional<Cart> cart = cartRepository.findByUserId(userId);
		
		Coupons coupon = dealsAndCouponsService.getCouponById(id);
		
		if(coupon != null) {
			List<Coupons> couponsList = cart.get().getCoupons();
			lg.info("Fetching All The Coupons In The Cart");
			for(Coupons c : couponsList) {
				lg.info("Traversing through all the list of coupons in the cart", c);
				if(c.getCouponId().equals(id)) {
					couponsList.remove(c);
					cartRepository.save(cart.get());
					return "Item deleted succesfully";
				}
			}
		}
		else {
			List<Deals> deals = cart.get().getDeals();
			lg.info("Deals {}", deals);
			for(Deals d: deals) {
				if(d.getProductId().equals(id)) {
					if(d.getQuantity()>1) {
						d.setQuantity(d.getQuantity()-1);
					}
					else{
						deals.remove(d);
					}
					cartRepository.save(cart.get());
					return "Item deleted succesfully";
				}
			}
		}
		
		return "Item deleted succesfully";
	}
//	public TransactionDetails createTransaction(Integer amount) {
//		try {
//			JSONObject jsonObject=new JSONObject();
//			jsonObject.put("amount", amount*100);
//			jsonObject.put("currency", CURRENCY);
//			RazorpayClient razorpayClient=new RazorpayClient(KEY,KEY_SECRET);
//		Order order   = razorpayClient.orders.create(jsonObject);
//		TransactionDetails transactionDetails=prepareTransactionDetail(order);
//		return transactionDetails;
//		} catch (RazorpayException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return null;
//	}
//	private TransactionDetails prepareTransactionDetail(Order order) {
// String orderId=order.get("id");
// String currency=order.get("currency");
// Integer amount=order.get("amount");
// TransactionDetails transactionDetails=new TransactionDetails(orderId,currency,amount);
// return transactionDetails;
//	}

	@Override
	public String deleteCartByUserId(String userId) {
		Optional<Cart> c=cartRepository.findByUserId(userId);
		 cartRepository.deleteByUserId(userId);
		return "Cart Deleted";
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		cartRepository.deleteAll();
	}

	

	
	
}