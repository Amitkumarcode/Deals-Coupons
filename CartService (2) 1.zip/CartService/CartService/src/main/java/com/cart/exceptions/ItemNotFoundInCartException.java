package com.cart.exceptions;

public class ItemNotFoundInCartException extends RuntimeException {
	
	public ItemNotFoundInCartException(String message) {
		super(message);
	}
}
