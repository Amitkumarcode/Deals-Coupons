package com.cart.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Coupons {
	
	
	private String couponId;
	private String couponName;
	private String couponCode;
	private String category;
	private String offerDetails;
	private double price;
	private String image;
}
