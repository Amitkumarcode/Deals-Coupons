//package com.Transaction.Paymentservice.repo;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import org.springframework.stereotype.Repository;
//
//import com.Transaction.Paymentservice.model.TransactionDetails;
//
//
//@Repository
//public interface PaymentRepository  extends JpaRepository<TransactionDetails,String> {
//
//}
