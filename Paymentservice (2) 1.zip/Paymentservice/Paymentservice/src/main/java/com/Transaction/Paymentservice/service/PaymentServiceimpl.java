package com.Transaction.Paymentservice.service;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Transaction.Paymentservice.model.TransactionDetails;
//import com.Transaction.Paymentservice.repo.PaymentRepository;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
@Service
public class PaymentServiceimpl implements PAymentservice {
//	@Autowired
//	private PaymentRepository pr;
	private static final String KEY = "rzp_test_ieEc1TjNzJBvzm";
	private static final String KEY_SECRET = "jh9urRjdG5LtRkdFOu1RuIQe";
	private static final String CURRENCY = "INR";

	@Override
	public TransactionDetails createTransaction(Integer amount) {
		try {
			JSONObject jsonObject=new JSONObject();
			jsonObject.put("amount", amount*100);
			jsonObject.put("currency", CURRENCY);
			RazorpayClient razorpayClient=new RazorpayClient(KEY,KEY_SECRET);
			Order order   = razorpayClient.orders.create(jsonObject);
			
			return prepareTransactionDetail(order);
		
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}
		private TransactionDetails prepareTransactionDetail(Order order) {
			 String orderId=order.get("id");
			 String currency=order.get("currency");
			 Integer amount=order.get("amount");
			 
			 TransactionDetails transactionDetails=new TransactionDetails(orderId,currency,amount,KEY);
			 
			 return transactionDetails;
		}
}
