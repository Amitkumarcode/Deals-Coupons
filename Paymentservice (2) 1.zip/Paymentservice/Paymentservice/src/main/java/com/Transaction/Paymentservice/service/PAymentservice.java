package com.Transaction.Paymentservice.service;

import com.Transaction.Paymentservice.model.TransactionDetails;

public interface PAymentservice {
	TransactionDetails createTransaction(Integer amount);
}
