package com.Buyer.buyer.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Buyer.buyer.dto.AuthRequest;
import com.Buyer.buyer.entities.UserCredential;
import com.Buyer.buyer.repository.UserCredentialRepository;
import com.Buyer.buyer.service.AuthService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/auth")
@Slf4j
@CrossOrigin("*")
public class AuthController {
	@Autowired
	private AuthService service;

	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserCredentialRepository userCredentialRepo;

	@PostMapping("/register")
	public String addNewUser(@RequestBody UserCredential user) {
		return service.saveUser(user);
	}

	@PostMapping("/token")
	public HashMap<String,String> getToken(@RequestBody AuthRequest authRequest) {
		log.info("Auth: {}", authRequest);
		 HashMap<String,String> map = new  HashMap<String,String>();
		Authentication authenticate = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
		log.info("Auth res {}", authenticate);
		if (authenticate.isAuthenticated()) {
			Optional<UserCredential> user = userCredentialRepo.findByName(authRequest.getUsername());
			map.put("Token", service.generateToken(authRequest.getUsername(),user.get().getRole()));
			map.put("id", user.get().getId()+"");
			map.put("role", user.get().getRole()+" ");
			return map; 
		} else {
			throw new RuntimeException("invalid access");
		}
	}

	@GetMapping("/validate")
	public String validateToken(@RequestParam("token") String token) {
		service.validateToken(token);
		return "Token is valid";
	}

	@GetMapping("/alluser")
	public List<UserCredential> getAllUser() {
		return service.getAllUser();

	}

	@GetMapping("/get/{id}")
	public UserCredential getById(@PathVariable int id) {
		return service.getById(id);
	}

	@DeleteMapping("/deleteAll")
	public void deleteAll() {
		service.deleteAll();
	}

	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable int id) {
		service.deleteById(id);
	}

	@PutMapping("/update/{id}")
	public UserCredential updateById(@RequestBody UserCredential user, @PathVariable int id) {
		return service.updateById(user, id);
	}
}
