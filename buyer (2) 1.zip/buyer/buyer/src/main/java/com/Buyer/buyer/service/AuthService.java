package com.Buyer.buyer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.Buyer.buyer.entities.UserCredential;

import com.Buyer.buyer.repository.UserCredentialRepository;

@Service
public class AuthService {

    @Autowired
    private UserCredentialRepository repository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    public String saveUser(UserCredential credential) {
        credential.setPassword(passwordEncoder.encode(credential.getPassword()));
        credential.setRole("User");
        repository.save(credential);
        return "user added to the system";
    }

    public String generateToken(String username,String role) {
        return jwtService.generateToken(username,role);
    }

    public void validateToken(String token) {
        jwtService.validateToken(token);
    }

	public List<UserCredential> getAllUser() {
		
		return repository.findAll();
	}

	public UserCredential  getById(int id) {
		UserCredential user=null;
		
		for(UserCredential u:repository.findAll()) {
			if(u.getId()==id)
				user=u;
			
		}
		return user ;
	}

	public void deleteAll() {
		// TODO Auto-generated method stub
		repository.deleteAll();
	}

	public void deleteById(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}
	public UserCredential updateById(UserCredential user,int id)
	{
		Optional<UserCredential> usr= repository.findById(id);
		usr.get().setId(user.getId());
		usr.get().setEmail(user.getEmail());
		usr.get().setName(user.getName());
		usr.get().setPassword(user.getPassword());
		return usr.get();
	}

}
