package com.Buyer.buyer.exception;

public class BuyerException extends Exception {
public BuyerException(String msg) {
	super(msg);
}
}
