package com.Buyer.buyer.exception;

import org.apache.hc.core5.http.HttpStatus;

public class ExceptionResponse {
private String errorMsg;
	
	private HttpStatus httpStatus;

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public ExceptionResponse(String errorMsg) {
		super();
		this.errorMsg = errorMsg;
	     this.httpStatus = httpStatus;
	}	
}



