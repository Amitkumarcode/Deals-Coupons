package com.dealsAndCoupons.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dealsAndCoupons.models.Coupons;
import com.dealsAndCoupons.models.Deals;
import com.dealsAndCoupons.services.DealsService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/deals")
@CrossOrigin("*")
public class DealsController {

	@Autowired
	private DealsService dealsService;
	
	private Logger logger = LoggerFactory.getLogger(CouponsController.class);

	
	
	@PostMapping("/save")
	public ResponseEntity<Deals> addDeals( @RequestBody Deals deal){
		
		Deals newDeal = dealsService.addDeals(deal);
		logger.info("Added new deal. Now exiting the add deal method");
		return new ResponseEntity<>(newDeal, HttpStatus.CREATED);
	}
	
	@GetMapping("/allDeals")
	public ResponseEntity<List<Deals>> getAllDeals(){
		logger.info("Inside get all deals method");
		List<Deals> listOfDeals = dealsService.getAllDeals();
		logger.info("Fetched a list of all deals");
		return new ResponseEntity<>(listOfDeals, HttpStatus.OK);
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<Deals> getDealsById(@PathVariable("id") String productId){
		
		Deals dealById = dealsService.getDealsById(productId);
		logger.info("Fetched the deal details");
		return new ResponseEntity<>(dealById, HttpStatus.OK);
	}
	
//	@GetMapping("/get/category/{category}")
//	public ResponseEntity<List<Deals>> getDealsByCategory(@Valid @PathVariable("category") String category){
//		logger.info("Fetching deals by category");
//		List<Deals> listOfDealsByCategory = dealsService.findByCategory(category);
//		logger.info("Fetched the deals list with the provided deal category");
//		return new ResponseEntity<>(listOfDealsByCategory, HttpStatus.OK);
//	}
	

	@PutMapping("/update/{id}")
	public ResponseEntity<Deals> updateDeal(@PathVariable("id") String productId,@RequestBody Deals deal){
		
		Deals updatedDeal = dealsService.getDealsById(productId);
		updatedDeal.setProductName(deal.getProductName());
		updatedDeal.setPrice(deal.getPrice());
		updatedDeal.setRating(deal.getRating());
		updatedDeal.setCategory(deal.getCategory());
		
		updatedDeal.setDescription(deal.getDescription());
		updatedDeal.setImage(deal.getImage());
		dealsService.updateDeal(updatedDeal);
		logger.info("Deals updated successfully");
		return new ResponseEntity<>(updatedDeal, HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteDealById(@PathVariable("id") String productId){
		logger.info("inside delete controller method");
		dealsService.deleteDeal(productId);
		logger.info("Deal with id {} successfully deleted",productId);
		return new ResponseEntity<>("Deal deleted successfully", HttpStatus.OK);
	}
}
