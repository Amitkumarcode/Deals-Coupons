package com.dealsAndCoupons.services.impl;

import java.util.List;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dealsAndCoupons.exceptions.CouponNotFoundException;
import com.dealsAndCoupons.models.Coupons;
import com.dealsAndCoupons.repositories.CouponsRepository;
import com.dealsAndCoupons.services.CouponsService;

@Service
public class CouponsServiceImpl implements CouponsService {

	@Autowired
	private CouponsRepository couponsRepository;

	private Logger logger = LoggerFactory.getLogger(CouponsServiceImpl.class);

	@Override
	public Coupons addCoupon(Coupons coupon) {

		Coupons savedCoupon = couponsRepository.save(coupon);
		logger.info("Coupon added successfully");

		return savedCoupon;
	}

	@Override
	public List<Coupons> getAllCoupons() {

		List<Coupons> couponsList = couponsRepository.findAll();

		logger.info("Ending method");
		return couponsList;
	}

	@Override
	public Coupons getCouponById(String couponId) {
		logger.info("Starting getCouponById method");
		Optional<Coupons> optionalCoupons = couponsRepository.findById(couponId);
		Coupons coupon = optionalCoupons.get();
		if (optionalCoupons.isEmpty()) {
			logger.info("Coupon with this couponId not found");

			throw new CouponNotFoundException("Coupon not found" + couponId);
		} else {
			logger.info("Coupon found");

			return coupon;
		}
	}

//	@Override
//	public List<Coupons> findByCategory(String category) {
//		
//		List<Coupons> categoryCoupons = couponsRepository.findByCategory(category);
//		if(categoryCoupons.isEmpty()) {
//			logger.info("Coupon  not found");
//			throw new CouponNotFoundException("Coupon not found "+ category);
//		}
//		else {
//			logger.info("Coupon found with the provided category");
//			
//			return categoryCoupons;
//		}	
//	}

//	@Override
//	public Coupons updateCoupon(Coupons coupon) {
//		logger.info("Started updateCoupon method");
//		Optional<Coupons> optionalCoupon = couponsRepository.findById(coupon.getCouponId());
//		if(optionalCoupon == null) {
//			logger.info("Unable to update - Coupon not found");
//			throw new CouponNotFoundException("Coupon not found "+ coupon.getCouponId() );
//		}
//		else {
//			logger.info("Coupon updated");
//		
//			Coupons updatedCoupon = couponsRepository.save(coupon);
//			return updatedCoupon;
//		}
//	}

	@Override
	public void deleteCoupon(String couponId) {
		;
		Coupons optionalCoupon = couponsRepository.findById(couponId)
				.orElseThrow(() -> new CouponNotFoundException("Coupon not found " + couponId));

		logger.info("Coupon deleted");

		Coupons deletedCoupon = optionalCoupon;
		couponsRepository.delete(deletedCoupon);

	}
//	Coupons updatedCoupon = couponsService.getCouponById(couponId);
//	updatedCoupon.setCouponName(coupon.getCouponName());
//	updatedCoupon.setCouponCode(coupon.getCouponCode());
//	updatedCoupon.setCategory(coupon.getCategory());
//	updatedCoupon.setOfferDetails(coupon.getOfferDetails());
//	updatedCoupon.setPrice(coupon.getPrice());
//	updatedCoupon.setImage(coupon.getImage());
//	couponsService.updateCoupon(updatedCoupon);
//	logger.info("Coupon updated");
//	return new ResponseEntity<>(updatedCoupon, HttpStatus.OK);
//}
//	@Override
//	public Coupons updateCoupon(Coupons coupons, String id) {
//		Optional<Coupons> c=couponsRepository.findById(id);
//		c.get().setCouponName(coupons.getCouponName());
//		c.get().setCategory(coupons.getCategory());
//		c.get().setOfferDetails(coupons.getOfferDetails());
//		c.get().setCouponCode(coupons.getCouponCode());
//		c.get().setPrice(coupons.getPrice());
//		couponsRepository.save(c);
//		return c.get();
//		
//		
//	}

	@Override
	public Coupons updateCoupon(Coupons coupons) {

//	if(coupons.getCouponId()!=null)
		Coupons c = couponsRepository.save(coupons);
		return c;
	}

}
