package com.dealsAndCoupons.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dealsAndCoupons.exceptions.CouponNotFoundException;
import com.dealsAndCoupons.models.Coupons;
import com.dealsAndCoupons.services.CouponsService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/coupons")
@CrossOrigin("*")
public class CouponsController {

	@Autowired
	private CouponsService couponsService;

	private Logger logger = LoggerFactory.getLogger(CouponsController.class);

	

//	@PostMapping("/save")
//	public ResponseEntity<Coupons> addCoupons( @RequestBody Coupons coupon) {
//		
//		Coupons newCoupon = couponsService.addCoupon(coupon);
//		logger.info(" new coupon added.");
//		return new ResponseEntity<>(newCoupon, HttpStatus.CREATED);
//	}
	@PostMapping("/save")
	public Coupons addCoupons(@RequestBody Coupons coupon) {
		logger.info("adding coupons");
		return couponsService.addCoupon(coupon);
	}
	

//	@GetMapping("/allCoupons")
//	public ResponseEntity<List<Coupons>> getAllCoupons() {
//		
//		List<Coupons> listOfCoupons = couponsService.getAllCoupons();
//		logger.info(" List of all coupons");
//		return new ResponseEntity<>(listOfCoupons, HttpStatus.OK);
//	}
	@GetMapping("allCoupons")
	public List<Coupons>getAllCoupons(){
		logger.info("List Of All Coupons");
		return couponsService.getAllCoupons();
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<Coupons> getCouponById(@PathVariable("id") String couponId) throws Exception{
		
		try {
			Coupons couponById = couponsService.getCouponById(couponId);
			if(couponId != null) {
				logger.info("Fetched the coupon");
				return new ResponseEntity<>(couponById, HttpStatus.OK);
			}
		}catch(Exception e){
			
		}
	
		return new ResponseEntity<>(null, HttpStatus.OK);
	}

//	@GetMapping("/get/category/{category}")
//	public ResponseEntity<List<Coupons>> getCouponByCategory( @PathVariable("category") String category) {
//		
//		List<Coupons> listOfCouponsByCategory = couponsService.findByCategory(category);
//		logger.info("Fetched the coupon list ");
//		return new ResponseEntity<>(listOfCouponsByCategory, HttpStatus.OK);
//	}

//	@PutMapping("/update/{id}")
//	public ResponseEntity<Coupons> updateCoupon(@PathVariable("id") String couponId,
//			@RequestBody Coupons coupon) {
//		
//		Coupons updatedCoupon = couponsService.getCouponById(couponId);
//		updatedCoupon.setCouponName(coupon.getCouponName());
//		updatedCoupon.setCouponCode(coupon.getCouponCode());
//		updatedCoupon.setCategory(coupon.getCategory());
//		updatedCoupon.setOfferDetails(coupon.getOfferDetails());
//		updatedCoupon.setPrice(coupon.getPrice());
//		updatedCoupon.setImage(coupon.getImage());
//		couponsService.updateCoupon(updatedCoupon);
//		logger.info("Coupon updated");
//		return new ResponseEntity<>(updatedCoupon, HttpStatus.OK);
//	}
//         @PutMapping("/update/{id}")
//         pubilc Coupons updateCoupon(@PathVariable String id,@RequestBody Coupons coupons) {
//         
//         }
	@PutMapping("/update/{id}")
	public Coupons updateCoupon(@PathVariable String id,@RequestBody Coupons coupons) {
		Coupons c=couponsService.getCouponById(id);
		c.setCategory(coupons.getCategory());
		c.setCouponCode(coupons.getCouponCode());
		c.setCouponName(coupons.getCouponName());
		c.setImage(coupons.getImage());
		c.setPrice(coupons.getPrice());
		c.setOfferDetails(coupons.getOfferDetails());
		return couponsService.updateCoupon(c);
		
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteCouponById(@PathVariable("id") String couponId) {
		
		couponsService.deleteCoupon(couponId);
		logger.info("Coupon deleted", couponId);
		return new ResponseEntity<>("Coupon deleted successfully", HttpStatus.OK);
	}
}
