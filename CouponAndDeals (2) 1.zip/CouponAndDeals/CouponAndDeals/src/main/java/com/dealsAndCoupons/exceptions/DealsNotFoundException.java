package com.dealsAndCoupons.exceptions;

public class DealsNotFoundException extends RuntimeException {
	
	public DealsNotFoundException(String message) {
		super(message);
	}
}
