package com.dealsAndCoupons.services;

import java.util.List;

import com.dealsAndCoupons.models.Deals;

public interface DealsService {
	

	
	Deals addDeals(Deals deal);
	
	List<Deals> getAllDeals();
	
	Deals getDealsById(String productId);
	
//	List<Deals> findByCategory(String category);
	
	
	
	Deals updateDeal(Deals deal);
	
	void deleteDeal(String productId);
	
}
