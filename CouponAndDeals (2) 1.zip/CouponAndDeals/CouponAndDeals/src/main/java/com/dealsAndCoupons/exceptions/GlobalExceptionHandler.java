package com.dealsAndCoupons.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.dealsAndCoupons.payload.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(CouponNotFoundException.class)
	public ResponseEntity<ApiResponse> handleCouponNotFoundException(CouponNotFoundException ex){
		String message = ex.getMessage();
		ApiResponse build = ApiResponse.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
		return new ResponseEntity<>(build, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(DealsNotFoundException.class)
	public ResponseEntity<ApiResponse> handleDealsNotFoundException(DealsNotFoundException ex){
		
		String message = ex.getMessage();
		ApiResponse build = ApiResponse.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
		return new ResponseEntity<>(build, HttpStatus.NOT_FOUND);
	}
}
