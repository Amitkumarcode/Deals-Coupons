package com.dealsAndCoupons.services.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dealsAndCoupons.exceptions.DealsNotFoundException;
import com.dealsAndCoupons.models.Deals;
import com.dealsAndCoupons.repositories.DealsRepository;
import com.dealsAndCoupons.services.DealsService;

@Service
public class DealsServiceImpl implements DealsService{
	
	@Autowired
	private DealsRepository dealsRepository;
	
	private Logger logger = LoggerFactory.getLogger(DealsServiceImpl.class);

	@Override
	public Deals addDeals(Deals deal) {
		
//		double disPrice = deal.getDiscountPercentage()*0.01;
//		
//		double discountedPrice = deal.getPrice() - (deal.getPrice()*disPrice);
//		deal.setDiscountedPrice(discountedPrice);
		Deals savedDeals = dealsRepository.save(deal);
		logger.info("Deal added successfully");
	
		return savedDeals;
	}

	@Override
	public List<Deals> getAllDeals() {
		
		List<Deals> dealsList = dealsRepository.findAll();
		logger.info("List of all deals fetched successfully");
		
		return dealsList;
	}

	@Override
	public Deals getDealsById(String productId) {
		
		Optional<Deals> optionalDeals = dealsRepository.findById(productId);
		Deals deal = optionalDeals.get();
		if(optionalDeals.isEmpty()) {
			logger.info("Deal not found");
			throw new DealsNotFoundException("Deal not found with the id "+ productId);
		}
		else {
			logger.info("Deals found");
		
			return deal;
		}	
	}

//	@Override
//	public List<Deals> findByCategory(String category) {
//		logger.info("Starting getDealsByCategory method");
//		List<Deals> categoryDeals = dealsRepository.findByCategory(category);
//		if(categoryDeals.isEmpty()) {
//			logger.info("Category not found");
//			throw new DealsNotFoundException("Coupon not found"+ category);
//		}
//		else {
//			logger.info("Coupon found with the provided category");
//			logger.info("Ending getCouponByCategory method");
//			Collections.sort(categoryDeals, new Comparator<Deals>() {
//
//				@Override
//				public int compare(Deals d1, Deals d2) {
//					
//					return Double.compare(d2.getDiscountPercentage(), d1.getDiscountPercentage());
//				}
//				
//			});
//			return categoryDeals;
//		}	
//	}

	
	@Override
	public Deals updateDeal(Deals deal) {
	
		Optional<Deals> optionalDeals = dealsRepository.findById(deal.getProductId());
		if(optionalDeals.isEmpty()) {
			logger.info("Deal not found");
			throw new DealsNotFoundException("Deal not found with the id "+ deal.getProductId() );
		}
		else {
			logger.info("Deal updated");
			
			Deals updatedDeals = dealsRepository.save(deal);
			return updatedDeals;
		}
	}

	@Override
	public void deleteDeal(String productId) {
		
		Optional<Deals> optionalDeals = dealsRepository.findById(productId);
		if(optionalDeals.isEmpty()) {
			logger.info("Unable to delete - Deal not found");
			throw new DealsNotFoundException("Deal not found with the id ");
		}
		else {
			logger.info("Deal deleted");
			
			Deals deletedDeal = optionalDeals.get();
			dealsRepository.delete(deletedDeal);
		}
		
	}

}
