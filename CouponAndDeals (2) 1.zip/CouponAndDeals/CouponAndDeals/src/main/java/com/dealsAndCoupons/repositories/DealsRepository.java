package com.dealsAndCoupons.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dealsAndCoupons.models.Deals;

@Repository
public interface DealsRepository extends JpaRepository<Deals, String> {

	List<Deals> findByCategory(String category);

	
}
