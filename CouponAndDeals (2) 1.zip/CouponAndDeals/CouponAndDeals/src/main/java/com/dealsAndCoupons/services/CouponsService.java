package com.dealsAndCoupons.services;

import java.util.List;
import java.util.Optional;

import com.dealsAndCoupons.models.Coupons;

public interface CouponsService {
	
	Coupons addCoupon(Coupons coupon);
	
	List<Coupons> getAllCoupons();
	
	Coupons getCouponById(String couponId);
	
//	List<Coupons> findByCategory(String category);
	
//	Coupons updateCoupon(Coupons coupon);
	
	void deleteCoupon(String couponId);

	Coupons updateCoupon(Coupons coupons);
}
